# Digital Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/zkfjnsd-kfjbsecuiae/pen/dyKovyj](https://codepen.io/zkfjnsd-kfjbsecuiae/pen/dyKovyj).

